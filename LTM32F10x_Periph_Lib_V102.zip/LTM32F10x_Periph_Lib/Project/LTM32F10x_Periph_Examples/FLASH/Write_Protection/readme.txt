1.例程描述 

本例介绍了LTM32F10x FLASH的写保护开关。

-启用写保护:

 要启用写保护，取消注释“#define WRITE_PROTECTION_ENABLE”行。

 在main.c文件中。 
为了保护一组页面，用户必须调用FLASH_EraseOptionBytes函数来擦除所有选项字节，

然后调用FLASH_EnableWriteProtection函数。后一个函数的参数将定义要保护的页面数量(所需的页面和已经保护的页面)。

为了加载新的选项字节值，系统重置是必要的，为此，使用函数NVIC_SystemReset()。
 
- 取消写保护:

   要禁用写保护，取消main.c文件中的“#define WRITE_PROTECTION_DISABLE”行注释。

要禁用LTM32F10x Flash的写保护，必须通过FLASH_EraseOptionBytes函数擦除OptionBytes，

然后调用FLASH_EnableWriteProtection函数来保护已经被保护的页面。

为了加载新的选项字节值，系统重置是必要的，为此，使用函数NVIC_SystemReset()。
   
- 对所选页面进行编程:

 要编写所需的页面(如果flash没有写保护)，取消main.c文件中的“#define FLASH_PAGE_PROGRAM”行注释。

如果需要的页面没有写保护，则执行擦除和写操作。



2、硬件和软件环境
   - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。


  
3.使用说明
