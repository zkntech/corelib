/**
  ******************************************************************************
  * @file    I2C/I2C_TSENSOR/main.c 
  * @author  Embedded Application Team
  * @version V3.5.0
  * @date    08-April-2023
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, LETO TECHNOLOGY SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2023 Leto Technology</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "ltm32f10x.h"
#include <stdlib.h>
#include "ltm32_eval.h"

/** @addtogroup LTM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup I2C_TSENSOR
  * @{
  */ 

/* Private typedef -----------------------------------------------------------*/
typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

/* Private define ------------------------------------------------------------*/
#define TEMPERATURE_THYS    31
#define TEMPERATURE_TOS     32

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
static int32_t TempValue = 0;
__IO uint8_t SMbusAlertOccurred = 0; 
      
/* Private functions ---------------------------------------------------------*/
void NVIC_Configuration(void);

/**
  * @brief   Main program
  * @param  None
  * @retval None
  */
int main(void)
{
  /*!< At this stage the microcontroller clock setting is already configured, 
       this is done through SystemInit() function which is called from startup
       file (startup_ltm32f10x_xx.s) before to branch to application main.
       To reconfigure the default setting of SystemInit() function, refer to
       system_ltm32f10x.c file
     */
 
  /* NVIC Configuration */
  NVIC_Configuration();

  /* Initialize printf */
  PrintfInit();
  
  /* Initialize the Temperature Sensor */
  LM75_Init();

  if (LM75_GetStatus() == SUCCESS)
  {     
    printf("     Temperature    ");
    
    /* Configure the Temperature sensor device STLM75:
    - Thermostat mode Interrupt
    - Fault tolerance: 00
    */
    LM75_WriteConfReg(0x02);
    
    /* Configure the THYS and TOS in order to use the SMbus alert interrupt */
    LM75_WriteReg(LM75_REG_THYS, TEMPERATURE_THYS << 8);  /*31'C*/
    LM75_WriteReg(LM75_REG_TOS, TEMPERATURE_TOS << 8);   /*32'C*/
    
    I2C_ClearITPendingBit(LM75_I2C, I2C_IT_SMBALERT);
    
    SMbusAlertOccurred = 0;
    
    /* Infinite Loop */
    while (1)
    {
      /* Get double of Temperature value */
      TempValue = LM75_ReadTemp();
      
	  printf("TempValue:%f\r\n",TempValue*0.5); 
		
      if (SMbusAlertOccurred == 1)
      {
		printf("Warning: Temp exceed 32 C��SMbusAlertOccurred=%d\r\n", SMbusAlertOccurred);
      }
      if (SMbusAlertOccurred == 2)
      {
        SMbusAlertOccurred = 0;
      }
    }
  }
  else
  {
	printf("LM75 not correctly initialized.Please restart the example.\r\n");	
    /* Infinite Loop */
    while(1)
    {
    }
  }
}

/**
  * @brief  Configures the different interrupt.
  * @param  None
  * @retval None
  */
void NVIC_Configuration(void)
{
  NVIC_InitTypeDef NVIC_InitStructure;
 
  NVIC_InitStructure.NVIC_IRQChannel = I2C1_ER_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}

#endif

/**
  * @}
  */ 

/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2023 Leto Technology *****END OF FILE****/
