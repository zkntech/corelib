1.例程描述  

这个示例展示了如何在Output Compare Inactive模式下配置TIM外设，并为每个通道提供相应的中断请求。

TIM2CLK频率设置为SystemCoreClock / 2 (Hz)，目标是将TIM2计数器时钟设置为1 KHz，因此预分频器计算如下:
   - Prescaler = (TIM2CLK / TIM2 counter clock) - 1

“SystemCoreClock”在“高密度”时设置为72mhz

TIM2 CCR1寄存器值等于1000:
TIM2_CC1 delay = CCR1_Val/TIM2 counter clock  = 1000 ms
因此，PC.06在等于1000毫秒的延迟后复位。

TIM2 CCR2寄存器值等于500:
TIM2_CC2 delay = CCR2_Val/TIM2 counter clock = 500 ms
因此，PC.07在等于500毫秒的延迟后重置。

TIM2 CCR3寄存器值等于250:
TIM2_CC3 delay = CCR3_Val/TIM2 counter clock = 250 ms
因此，PC.08在等于250毫秒的延迟后重置。

TIM2 CCR4寄存器值等于125:
TIM2_CC4 delay = CCR4_Val/TIM2 counter clock = 125 ms
因此，PC.09在等于125毫秒的延迟后复位。

虽然计数器低于输出比较寄存器值，这决定了输出延迟，PC.06, PC.07, PC.08和PC.09引脚被打开。 

当计数器值达到输出比较寄存器值时，将生成输出比较中断，并且在处理程序例程中关闭这些引脚。


2、硬件和软件环境

- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL 设置 
    - 将以下引脚连接到示波器以监测不同的波形:
        - PC.06
        - PC.07
        - PC.08 
        - PC.09
  
3.使用说明