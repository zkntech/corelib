1.例程描述 

这个例子展示了如何使用TIM外设在定时器输入引脚接收到外部信号的上升沿后产生一个单脉冲模式。

TIM2CLK = SystemCoreClock，我们想获得TIM2时钟在24 MHz:
  - Prescaler = (TIM2CLK / TIM2 counter clock) - 1
“SystemCoreClock”在“高密度”时设置为72mhz


自动加载值是65535 (TIM4->ARR)，所以触发TIM4输入的最大频率值是240000000 /65535 = 300 Hz。

TIM4配置如下:
使用One Pulse模式，外部信号连接到TIM4 CH2引脚(pbb .07)，上升沿用作活动沿，
One Pulse信号在TIM4_CH1 (pbb .06)上输出。

TIM_Pulse定义了延迟值，延迟值固定为:
延时= CCR1/TIM4，计数器= 16383 / 24000000 = 682.6 us。
(TIM_Period - TIM_Pulse)定义了一个脉冲值，脉冲值固定为:
一个脉冲值= (TIM_Period - TIM_Pulse)/TIM4计数器
                = (65535 - 16383) / 24000000 = 2.048 ms.

  
2、硬件和软件环境

- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   -LTM32F10X-EVAL 设置 
   - 将外部信号连接到TIM4_CH2引脚(PB.07)
   - 将TIM4_CH1 (PB.06)引脚连接到示波器以监测波形。
  
3.使用说明
