1.例程描述 

这个示例展示了如何在输出比较时序模式下配置TIM外设，并为每个通道提供相应的中断请求，以便生成4个不同的时间基。

TIM2CLK频率设置为SystemCoreClock / 2 (Hz)，以获得TIM2计数器在6 MHz，因此预caler计算如下:
   - Prescaler = (TIM2CLK / TIM2 counter clock) - 1

“SystemCoreClock”在“高密度”时设置为72mhz。

TIM2 CC1寄存器值等于40961，
CC1更新速率= TIM2计数器/ CCR1_Val = 146.48 Hz，
因此TIM2通道1每6.8ms产生一个中断

TTIM2 CC2寄存器等于27309，
CC2更新速率= TIM2计数器/ CCR2_Val = 219.7 Hz
因此TIM2通道2每4.55ms产生一个中断

TIM2 CC3寄存器等于13654，
CC3更新速率= TIM2计数器/ CCR3_Val = 439.4Hz
因此TIM2通道3每2.27ms产生一个中断

TIM2 CC4寄存器等于6826，
CC4更新速率= TIM2计数器/ CCR4_Val = 878.9 Hz
因此TIM2通道4每1.13ms产生一个中断。

当计数器值达到输出比较寄存器值时，输出
比较中断生成和，在处理程序例程中，4引脚(PC。06、PC.07电脑。08和PC.09)以以下频率切换:

- PC.06: 73.24Hz (CC1)
- PC.07: 109.8Hz (CC2)
- PC.08: 219.7Hz (CC3) 
- PC.09: 439.4Hz (CC4)

2、硬件和软件环境


- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   -LTM32F10X-EVAL 设置 
    - 在PC.06、PC.07、PC.08和PC.09上连接一个示波器，显示不同的时基信号。
  
3.使用说明
