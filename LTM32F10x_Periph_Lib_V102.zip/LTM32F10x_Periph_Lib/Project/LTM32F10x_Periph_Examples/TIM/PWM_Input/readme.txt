1.例程描述 

这个例子展示了如何使用TIM外设来测量频率和外部信号的占空比。

TIMxCLK频率设置为SystemCoreClock (Hz)， precaler为0，因此TIM3计数器为SystemCoreClock (Hz)。

“SystemCoreClock”在“高密度”时设置为72mhz


TIM3配置为PWM输入模式:外部信号连接到TIM3 Channel2作为输入引脚。

为了测量频率和占空比，我们使用TIM3 CC2中断请求，因此在TIM3_IRQHandler例程中，计算外部信号的频率和占空比
“Frequency”变量包含外部信号频率:
频率= TIM3计数器/ TIM3_CCR2 (Hz)，
“DutyCycle”变量包含外部信号占空比:
DutyCycle = (TIM3_CCR1*100)/(TIM3_CCR2) in %。

对于高密度设备需要测量的最小频率值为1100hz。


2、硬件和软件环境

- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL设置 

    - 将外部测量信号连接到TIM3 CH2引脚(PA.07)。 
  
3.使用说明
