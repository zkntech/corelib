1.例程描述 

这个例子展示了如何在PWM(脉冲宽度调制)模式下配置TIM外设。

TIM3CLK频率设置为SystemCoreClock / 2 (Hz)，以获得TIM3计数器在24 MHz的预caler计算如下:

   - Prescaler = (TIM3CLK / TIM3 counter clock) - 1

“SystemCoreClock”在“高密度”时设置为72mhz。

TIM3频率= TIM3计数器/(ARR + 1)
              = 24 MHz / 666 = 36 KHz
TIM3 CCR1寄存器值等于500，因此TIM3通道1产生频率为36 KHz、占空比为50%的PWM信号:
TIM3 Channel1占空比= (TIM3_CCR1/ TIM3_ARR + 1)* 100 = 50%

TIM3 CCR2寄存器值为375，因此TIM3通道2产生频率为36khz、占空比为37.5%的PWM信号:
TIM3 Channel2占空比= (TIM3_CCR2/ TIM3_ARR + 1)* 100 = 37.5%

TIM3 CCR3寄存器值等于250，因此TIM3通道3产生频率为36khz，占空比为25%的PWM信号:
TIM3 Channel3占空比= (TIM3_CCR3/ TIM3_ARR + 1)* 100 = 25%

TIM3 CCR4寄存器值为125，因此TIM3 Channel 4产生频率为36khz、占空比为12.5%的PWM信号:
TIM3 Channel4占空比= (TIM3_CCR4/ TIM3_ARR + 1)* 100 = 12.5%

PWM波形可以用示波器显示。

2、硬件和软件环境


- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   -LTM32F10X-EVAL 设置  
    - 将以下引脚连接到示波器上，以监测不同的示波器波形:
        - PA.06: (TIM3_CH1)
        - PA.07: (TIM3_CH2)
        - PB.00: (TIM3_CH3)
        - PB.01: (TIM3_CH4)  
  
3.使用说明
