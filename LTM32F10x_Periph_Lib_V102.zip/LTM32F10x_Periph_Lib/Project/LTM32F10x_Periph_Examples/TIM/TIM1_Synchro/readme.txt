1.例程描述 

这个示例展示了如何以并行模式同步TIM1和TIM3和TIM4。

定时器同步并行模式:

1/ TIM1配置为Master Timer:
 -使用PWM模式
 -TIM1 Update事件用作触发器输出
 
2/ TIM3和TIM4是TIM1的从机;
 - 使用PWM模式
 - ITR0(TIM1)用作两个从机的输入触发器
 - 使用门控模式，因此奴隶计数器的启动和停止由主触发器输出信号(更新事件)控制。

o高密度设备:TIMxCLK固定为72 MHz, precaler = 0，因此TIM1计数器为72 MHz


 主定时器TIM1运行于:
 TIM1频率= TIM1计数器/ (TIM1_Period + 1) = 281.250 KHz
 占空比为:TIM1_CCR1/(TIM1_ARR + 1) = 50%

 TIM3运行在:
 (TIM1频率)/ ((TIM3周期+1)* (Repetition_Counter+1)) = 18.750 KHz
 占空比TIM3_CCR1/(TIM3_ARR + 1) = 33.3%

TIM4运行在:
(TIM1频率)/ ((TIM4周期+1)* (Repetition_Counter+1)) = 28.125 KHz
占空比为TIM4_CCR1/(TIM4_ARR + 1) = 50%
  

2、硬件和软件环境

- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL设置 
   - 将以下引脚连接到示波器以监测不同的波形:
      - TIM1 CH1 (PA.08)
      - TIM3 CH1 (PA.06)
      - TIM4 CH1 (PB.06)  
  
3.使用说明