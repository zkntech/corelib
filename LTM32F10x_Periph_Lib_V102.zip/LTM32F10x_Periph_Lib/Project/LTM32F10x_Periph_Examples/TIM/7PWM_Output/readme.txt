1.例程描述 

这个例子展示了如何配置TIM1外设来产生7个PWM信号，具有4个不同的占空比(50%，37.5%，25%和12.5%)。

TIM1CLK = SystemCoreClock, precaler = 0, TIM1计数器= SystemCoreClock
“SystemCoreClock”在“高密度”时设置为72mhz

目标是在17.57 KHz产生7个PWM信号:
  - TIM1_Period = (SystemCoreClock / 17570) - 1

通道1和通道1N占空比设置为50%
通道2和通道2N占空比设置为37.5%
通道3和通道3N占空比设置为25%
通道4占空比设置为12.5%

Timer脉冲的计算方法如下:
  - ChannelxPulse = DutyCycle * (TIM1_Period - 1) / 100

TIM1波形可以用示波器显示。


2、硬件和软件环境
      

 - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL 设置  
    - 将TIM1引脚连接到示波器以监测不同的波形:
      - TIM1_CH1  pin (PA.08)  
      - TIM1_CH1N pin (PB.13)  
      - TIM1_CH2  pin (PA.09)  
      - TIM1_CH2N pin (PB.14)  
      - TIM1_CH3  pin (PA.10)  
      - TIM1_CH3N pin (PB.15)
      - TIM1_CH4  pin (PA.11)    
  
3.使用说明
