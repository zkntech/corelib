1.例程描述 

这个示例展示了如何配置TIM3外设，以生成四个不同频率的四个不同信号。

TIM3CLK频率设置为SystemCoreClock / 2 (Hz)，我们希望获得TIM3计数器在12 MHz，因此预分频器计算如下:
   - Prescaler = (TIM3CLK / TIM3 counter clock) - 1
SystemCoreClock”在“高密度”时设置为72mhz

TIM3 CCR1寄存器值等于32768:
CC1 update rate = TIM3 counter clock / CCR1_Val = 366.2 Hz,
因此TIM3通道1产生频率等于183.1 Hz的周期信号。

TIM3 CCR2寄存器等于16384:
CC2 update rate = TIM3 counter clock / CCR2_Val = 732.4 Hz
因此TIM3通道2产生频率等于366.3 Hz的周期信号。

TIM3 CCR3寄存器等于8192:
CC3 update rate = TIM3 counter clock / CCR3_Val = 1464.8 Hz
因此TIM3通道3产生频率等于732.4 Hz的周期信号。

TIM3 CCR4寄存器等于4096:
CC4 update rate = TIM3 counter clock / CCR4_Val =  2929.6 Hz
因此TIM3通道4产生频率等于1464.8 Hz的周期信号。

2、硬件和软件环境

- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL 设置 
    -将TIM1引脚(TIM3全重映射引脚)连接到示波器以监测不同的波形:
       - PA.06 (TIM3_CH1)
       - PA.07 (TIM3_CH2)
       - PB.00 (TIM3_CH3)
       - PB.01 (TIM3_CH4) 

  
3.使用说明
