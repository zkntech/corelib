1.例程描述 

本示例描述了如何在同一个应用程序中使用软件NSS管理设置SPIy和SPIz之间的全双工模式通信，
并执行从主到从、从到主的传输。

SPIy和SPIz可以是SPI1和SPI2或SPI3和SPI2，具体取决于您使用的列拓科技EVAL板

两个spi都配置了8位数据帧和9Mbit/s的通信速度。
(对于值线设备，速度设置为6Mbit/s)。

在第一阶段，主SPIz启动SPIy_Buffer_Tx传输，而从SPIz传输SPIz_Buffer_Tx。一旦传输完成，比较就完成了，TransferStatus1和TransferStatus2给出了每个数据传输方向的数据传输状态，
如果传输和接收的数据相同，则为PASSED，否则为FAILED。

由于NSS引脚是由软件管理的，这就允许SPIy在没有硬件修改的情况下成为从属和主从属。

在第二步中，从SPIz启动SPIy_Buffer_Tx传输，而主SPIz传输SPIz_Buffer_Tx。一旦传输完成，比较就完成了，TransferStatus3和TransferStatus4给出了每个数据传输方向的数据传输状态，
如果传输和接收的数据相同，则为PASSED，否则为FAILED。



2、硬件和软件环境

  - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   -LTM32F10X-EVAL 设置 
    - 连接SPI1 SCK引脚(PA.05)到SPI2 SCK引脚(PB.13)

    - 连接SPI1 MISO引脚(PA.06)到SPI2 MISO引脚(PB.14)

    -连接SPI1 MOSI引脚(PA.07)到SPI2 MOSI引脚(PB.15)


    
3.使用说明
