
  
1.例程描述 

本示例提供了一个基本示例，说明如何使用SPI固件库和关联SPI FLASH驱动程序与M25P64或M25P128 FLASH进行通信。

第一步包括读取SPI Flash ID。从SPI闪存读取的ID与预期的ID进行比较，如果成功则打开LED1，否则打开LED2。

使用这个驱动程序，程序执行要访问的扇区的擦除，在main.c文件中定义的Tx_Buffer写入内存，然后读取写入的数据。

然后将从Rx_Buffer中存储的内存中读取的数据与Tx_Buffer的期望值进行比较。

比较的结果存储在“TransferStatus1”变量中。

最后对同一扇区进行第二次擦除，并进行测试以确保所有写入的数据都被擦除到扇区擦除处。

读取所有的数据位置并使用0xFF值进行检查。该测试的结果存储在“TransferStatus2”变量中，如果出现错误，该变量为FAILED。

SPI1配置为Master，数据大小为8位。SPI1波特率设置为18mbit /s。

程序开始写和读操作的FLASH_WriteAddress和FLASH_ReadAddress在main.c文件中定义。



2、硬件和软件环境

- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL设置 
    - 使用LED1和LED2分别连接到PF.06和PF.07引脚

    - M25P64 FLASH已经在该板上可用。

		  
  - 其他平台设置
    -将LED1和LED2分别连接到PD.07和PD.13引脚
    -连接SPI1和SPI FLASH引脚如下:
      - 连接SPI1_NSS (PA.04)引脚到SPI Flash芯片select (pin1)
      - 连接SPI1_SCLK (PA.05)引脚到SPI Flash串行时钟(引脚6)
      - 连接SPI1_MISO (PA.06)引脚到SPI Flash串行数据输出(引脚2)
      - 连接SPI1_MOSI (PA.07)引脚到SPI Flash串行数据输入(引脚5)
      - 连接SPI Flash写保护(pin3)到Vdd
      - 将SPI Flash Hold (pin7)连接到Vdd
      - 连接SPI Flash Vcc (pin8)到Vdd
      - 连接SPI Flash Vss (pin4)到Vss


3.使用说明
