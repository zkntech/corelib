1.例程描述 

这个示例描述了如何在两个spi之间以单工模式设置通信，并使用主用TxE中断和从用RxNE中断执行
从SPI_MASTER到SPI_SLAVE的数据缓冲区传输。

SPI_MASTER和SPI_SLAVE可以是SPI1和SPI2或SPI3和SPI2，具体取决于您使用的列拓科技EVAL板。

两个spi都配置了8位数据帧和9Mbit/s的通信速度

主机启用TxE中断，从机启用RxNE中断。

一旦两个spi都被启用，第一个TxE中断就会为主机生成，并且在它的中断服务例程中，
第一个数据从SPI_MASTER_Buffer_Tx发送。

一旦从服务器接收到该数据，就会生成RxNE中断，并在例程中将该数据存储在SPI_SLAVE_Buffer_Rx中。

对剩余的SPI_MASTER_Buffer_Tx数据遵循相同的过程。

一旦所有数据缓冲区被从机接收，TxE中断被禁用。

比较完成后，TransferStatus变量给出数据传输状态，如果传输和接收的数据相同，则为PASSED，否则为FAILED。

2、硬件和软件环境

  - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL 设置 
    - 连接SPI1 SCK引脚(PA.05)到SPI2 SCK引脚(PB.13)
    - 连接SPI1 MOSI引脚(PA.07)到SPI2 MISO引脚(PB.14)


    
	
3.使用说明



