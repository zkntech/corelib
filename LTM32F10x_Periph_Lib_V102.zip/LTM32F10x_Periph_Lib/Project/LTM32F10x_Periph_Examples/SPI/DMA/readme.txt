1.例程描述 

这个示例描述了如何在单路模式下设置两个spi之间的通信，并执行从轮询模式下的SPI_MASTER到
DMA接收模式下的SPI_SLAVE的传输。

SPI_MASTER和SPI_SLAVE可以是SPI1和SPI2或SPI3和SPI2，具体取决于您使用的列拓科技EVAL板。

两个spi都配置了8位数据帧和18Mbit/s的通信速度。

SPI_MASTER在双向模式下配置为仅发送方，而SPI_SLAVE在双向模式下配置为仅接收方。主和从NSS引脚都由硬件管理。

为SPI_SLAVE Rx请求配置了一个专用的DMA通道，以便将接收到的数据存储在SPI_SLAVE_Buffer_Rx中。

SPI_MASTER首先传输第一个数据，一旦SPI_SLAVE接收到该数据，RxNE请求将触发DMA传输该数据并将
其存储到SPI_SLAVE_Buffer_Rx中。对缓冲区的其余部分执行相同的操作。

一旦传输完成，将进行比较，TransferStatus给出数据传输状态，如果传输和接收的数据相同，则为PASSED，否则为FAILED。




2、硬件和软件环境

  - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL 设置 
    - 连接SPI2 NSS引脚(PB.12)到SPI1 NSS引脚(PA.04)
    -  连接 SPI2 SCK pin (PB.13) to SPI1 SCK pin (PA.05)
    - 连接SPI2 SCK引脚(PB.14)到SPI1 SCK引脚(PA.07)

    
3.使用说明
