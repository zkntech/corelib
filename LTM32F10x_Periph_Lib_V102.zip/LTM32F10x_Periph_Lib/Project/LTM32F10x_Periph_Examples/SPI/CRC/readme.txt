
1.例程描述 


本示例描述了如何在两个spi之间设置全双工模式的通信，并执行从主到从和从到主的传输，然后进行CRC传输。

SPI1配置为主，SPI2配置为从，两者都是全双工配置模式，数据大小为16位，通信速度为4.5 Mbit/s。
 
两个spi都使能CRC计算

启用这两个spi后，从服务器发送来自SPI2_Buffer_Tx的第一个数据，然后是主服务器发送来自SPI1_Buffer_Tx的第一个数据。
对RxNE标志进行测试，以检查主服务器和从服务器各自数据寄存器上的数据接收情况。对其余数据执行相同的过程除了最后一个。

传输SPI1_Buffer_Tx的最后一个数据，然后为SPI1启用CRC传输;传输SPI2_Buffer_Tx的最后一个数据，
然后为SPI2启用CRC传输:用户必须注意在此阶段减少代码以实现高速通信。

最后发送的缓冲区数据和CRC值依次在主数据寄存器和从数据寄存器上接收。接收到的CRC值分别存储在SPI1和SPI2的CRC1Value和CRC2Value上。

一旦传输完成，比较就完成了，TransferStatus1和TransferStatus2给出了每个数据传输方向的数据传输状态，如果传输和接收的数据相同，
则为PASSED，否则为FAILED。

在接收到CRC数据后，对主机和备机进行CRC错误标志的检查。


  
2、硬件和软件环境

- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL 设置 
     - 连接SPI1 SCK (PA.05)引脚到SPI2 SCK (PB.13)引脚

     - 连接SPI1 MISO (PA.06)引脚到SPI2 MISO (PB.14)引脚

     - 连接SPI1 MOSI (PA.07)引脚到SPI2 MOSI (PB.15)引脚


	 
3.使用说明
