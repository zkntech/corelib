/**
  ******************************************************************************
  * @file    USART/DMA_Interrupt/main.c
  * @author  Embedded Application Team
  * @version V3.5.0
  * @date    08-April-2023
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, LETO TECHNOLOGY SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2023 Leto Technology</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "ltm32f10x.h"
#include "platform_config.h"
#include "ltm32_eval.h"

/** @addtogroup LTM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup USART_DMA_Interrupt
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
typedef enum {FAILED = 0, PASSED = !FAILED} TestStatus;

/* Private define ------------------------------------------------------------*/
#define TxBufferSize1   (countof(TxBuffer1) - 1)
#define TxBufferSize2   (countof(TxBuffer2) - 1)

/* Private macro -------------------------------------------------------------*/
#define countof(a)   (sizeof(a) / sizeof(*(a)))

/* Private variables ---------------------------------------------------------*/
USART_InitTypeDef USART_InitStructure;
uint8_t TxBuffer1[] = "USART DMA Interrupt: USARTy -> USARTz using DMA Tx and Rx Flag";
uint8_t TxBuffer2[] = "USART DMA Interrupt: USARTz -> USARTy using DMA Tx and Rx Interrupt";
uint8_t RxBuffer1[TxBufferSize2];
uint8_t RxBuffer2[TxBufferSize1];
uint8_t NbrOfDataToRead = TxBufferSize1;
uint32_t Index = 0;
volatile TestStatus TransferStatus1 = FAILED, TransferStatus2 = FAILED;
__IO uint32_t TimingDelay = 0;

/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration( void );
void GPIO_Configuration( void );
void NVIC_Configuration( void );
void DMA_Configuration( void );
TestStatus Buffercmp( uint8_t *pBuffer1, uint8_t *pBuffer2, uint16_t BufferLength );

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Inserts a delay time.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
  */
void Delay( __IO uint32_t nTime )
{
	TimingDelay = nTime;

	while( TimingDelay != 0 );
}

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main( void )
{
	/*!< At this stage the microcontroller clock setting is already configured,
	     this is done through SystemInit() function which is called from startup
	     file (startup_ltm32f10x_xx.s) before to branch to application main.
	     To reconfigure the default setting of SystemInit() function, refer to
	     system_ltm32f10x.c file
	   */
	
	/* Initialize LED1&LED2  mounted on LTM3210X-EVAL board */
	LTM_EVAL_LEDInit( LED1 );
	LTM_EVAL_LEDInit( LED2 );

	/* System Clocks Configuration */
	RCC_Configuration();

	/* NVIC configuration */
	NVIC_Configuration();

	/* Configure the GPIO ports */
	GPIO_Configuration();

	/* Configure the DMA */
	DMA_Configuration();

	/* Setup SysTick Timer for 1 msec interrupts  */
	if( SysTick_Config( SystemCoreClock / 1000 ) )
	{
		/* Capture error */
		while( 1 );
	}

	/* USARTy and USARTz configuration -------------------------------------------*/
	/* USARTy and USARTz configured as follow:
	      - BaudRate = 230400 baud
	      - Word Length = 8 Bits
	      - One Stop Bit
	      - No parity
	      - Hardware flow control disabled (RTS and CTS signals)
	      - Receive and transmit enabled
	*/

	USART_InitStructure.USART_BaudRate = 230400;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	/* Configure USARTy */
	USART_Init( USARTy, &USART_InitStructure );

	/* Configure USARTz */
	USART_Init( USARTz, &USART_InitStructure );

	/* Enable USARTy DMA TX request */
	USART_DMACmd( USARTy, USART_DMAReq_Tx, ENABLE );

	/* Enable USARTz DMA TX request */
	USART_DMACmd( USARTz, USART_DMAReq_Tx, ENABLE );

	/* Enable the USARTz Receive Interrupt */
	USART_ITConfig( USARTz, USART_IT_RXNE, ENABLE );

	/* Enable USARTy */
	USART_Cmd( USARTy, ENABLE );

	/* Enable USARTz */
	USART_Cmd( USARTz, ENABLE );

	/* Enable USARTy DMA TX Channel */
	DMA_Cmd( USARTy_Tx_DMA_Channel, ENABLE );

	/* Enable USARTz DMA TX Channel */
	DMA_Cmd( USARTz_Tx_DMA_Channel, ENABLE );

	/* Receive the TxBuffer2 */
	while( Index < TxBufferSize2 )
	{
		while( USART_GetFlagStatus( USARTy, USART_FLAG_RXNE ) == RESET )
		{
		}

		RxBuffer1[Index++] = USART_ReceiveData( USARTy );
	}

	/* Wait until USARTy TX DMA1 Channel  Transfer Complete */
	while( DMA_GetFlagStatus( USARTy_Tx_DMA_FLAG ) == RESET )
	{
	}

	/* Wait until USARTz TX DMA1 Channel Transfer Complete */
	while( DMA_GetFlagStatus( USARTz_Tx_DMA_FLAG ) == RESET )
	{
	}

	/* Check the received data with the send ones */
	TransferStatus1 = Buffercmp( TxBuffer2, RxBuffer1, TxBufferSize2 );
	/* TransferStatus1 = PASSED, if the data transmitted from USARTz and
	   received by USARTy are the same */
	/* TransferStatus1 = FAILED, if the data transmitted from USARTz and
	   received by USARTy are different */
	TransferStatus2 = Buffercmp( TxBuffer1, RxBuffer2, TxBufferSize1 );
	/* TransferStatus2 = PASSED, if the data transmitted from USARTy and
	   received by USARTz are the same */
	/* TransferStatus2 = FAILED, if the data transmitted from USARTy and
	   received by USARTz are different */

	if( ( TransferStatus1==1 )&&( TransferStatus2==1 ) )
	{
		/* Turn on LED1 */
		LTM_EVAL_LEDOn( LED1 );
	}

	while( 1 )
	{
		/* Toggle LED2 */
		LTM_EVAL_LEDToggle( LED2 );

		/* Insert 200 ms delay */
		Delay( 200 );
	}
}

/**
  * @brief  Configures the different system clocks.
  * @param  None
  * @retval None
  */
void RCC_Configuration( void )
{
	/* DMA clock enable */
	RCC_AHBPeriphClockCmd( RCC_AHBPeriph_DMA1, ENABLE );

	/* Enable GPIO clock */
	RCC_APB2PeriphClockCmd( USARTy_GPIO_CLK | USARTz_GPIO_CLK | RCC_APB2Periph_AFIO, ENABLE );
	/* Enable USARTy Clock */
	RCC_APB2PeriphClockCmd( USARTy_CLK, ENABLE );
	/* Enable USARTz Clock */
	RCC_APB1PeriphClockCmd( USARTz_CLK, ENABLE );
}

/**
  * @brief  Configures the different GPIO ports.
  * @param  None
  * @retval None
  */
void GPIO_Configuration( void )
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Configure USARTy Rx as input floating */
	GPIO_InitStructure.GPIO_Pin = USARTy_RxPin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init( USARTy_GPIO, &GPIO_InitStructure );

	/* Configure USARTz Rx as input floating */
	GPIO_InitStructure.GPIO_Pin = USARTz_RxPin;
	GPIO_Init( USARTz_GPIO, &GPIO_InitStructure );

	/* Configure USARTy Tx as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = USARTy_TxPin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init( USARTy_GPIO, &GPIO_InitStructure );

	/* Configure USARTz Tx as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = USARTz_TxPin;
	GPIO_Init( USARTz_GPIO, &GPIO_InitStructure );
}

/**
  * @brief  Configures the nested vectored interrupt controller.
  * @param  None
  * @retval None
  */
void NVIC_Configuration( void )
{
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Enable the USARTz Interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = USARTz_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init( &NVIC_InitStructure );
}

/**
  * @brief  Configures the DMA.
  * @param  None
  * @retval None
  */
void DMA_Configuration( void )
{
	DMA_InitTypeDef DMA_InitStructure;

	/* USARTy_Tx_DMA_Channel (triggered by USARTy Tx event) Config */
	DMA_DeInit( USARTy_Tx_DMA_Channel );
	DMA_InitStructure.DMA_PeripheralBaseAddr = USARTy_DR_Base;
	DMA_InitStructure.DMA_MemoryBaseAddr = ( uint32_t )TxBuffer1;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = TxBufferSize1;
	DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
	DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
	DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
	DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;
	DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
	DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
	DMA_Init( USARTy_Tx_DMA_Channel, &DMA_InitStructure );

	/* USARTz_Tx_DMA_Channel (triggered by USARTz Tx event) Config */
	DMA_DeInit( USARTz_Tx_DMA_Channel );
	DMA_InitStructure.DMA_PeripheralBaseAddr = USARTz_DR_Base;
	DMA_InitStructure.DMA_MemoryBaseAddr = ( uint32_t )TxBuffer2;
	DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
	DMA_InitStructure.DMA_BufferSize = TxBufferSize2;
	DMA_Init( USARTz_Tx_DMA_Channel, &DMA_InitStructure );
}

/**
  * @brief  Compares two buffers.
  * @param  pBuffer1, pBuffer2: buffers to be compared.
  * @param  BufferLength: buffer's length
  * @retval PASSED: pBuffer1 identical to pBuffer2
  *         FAILED: pBuffer1 differs from pBuffer2
  */
TestStatus Buffercmp( uint8_t *pBuffer1, uint8_t *pBuffer2, uint16_t BufferLength )
{
	while( BufferLength-- )
	{
		if( *pBuffer1 != *pBuffer2 )
		{
			return FAILED;
		}

		pBuffer1++;
		pBuffer2++;
	}

	return PASSED;
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed( uint8_t *file, uint32_t line )
{
	/* User can add his own implementation to report the file name and line number,
	   ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	/* Infinite loop */
	while( 1 )
	{
	}
}

#endif

/**
  * @}
  */

/**
  * @}
  */

/******************* (C) COPYRIGHT 2023 Leto Technology *****END OF FILE****/
