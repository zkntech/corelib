1、例程描述 

这个例子使用DMA功能、标志和中断提供了USARTy和USARTz之间的基本通信。USARTy和USARTz可以是USART1和USART2或USART2和USART3，
具体取决于您使用的核心板

首先，DMA将数据从TxBuffer2缓冲区传输到USARTz传输数据寄存器，然后将该数据发送到USARTy。
USARTy接收到的数据使用RXNE标志进行传输，并存储在RxBuffer1中，然后与发送的数据和进行比较
比较的结果存储在“TransferStatus1”变量中。
 
同时，DMA将数据从TxBuffer1缓冲区传输到USARTy传输数据寄存器，然后将该数据发送到USARTz。USARTz接收到的数据使用Receive中断传输并存储在RxBuffer2
中，然后与发送的数据进行比较，这种比较的结果存储在“TransferStatus2”变量中。

USARTy和USARTz配置如下:
  - 波特率= 230400波特
  - 字长= 8位
  - 一个停止位
  - 没有奇偶校验
  - 硬件流控制被禁用(RTS和CTS信号)
  - 启用接收和发送    
        
2、硬件和软件环境 
              
- 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL 设置 
    - 在CN12 (USART1)和CN8 (USART2)之间连接一根空调制解调器母/母RS232电缆
    

  
3、使用说明


