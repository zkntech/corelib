1.例程描述 

这个例子描述了如何在多处理器模式下使用USART。USARTy和USARTz可以分别为USART1和USART2或USART2和USART3，
具体取决于您使用的列拓科技核心板。

首先，将USARTy和USARTz地址设置为0x1和0x2。USARTy连续向USARTz发送字符0x33。USARTz在接收0x33时切换LED1,
 LED2引脚。

当在BUTTON_KEY EXTI线上应用下降沿时，将生成中断，并在EXTI0_IRQHandler例程中设置USART节点的地址。

在这个中断例程中，USARTy发送地址标记字符(0x102)来唤醒USARTz。LED重启切换
USARTy和USARTz配置如下:
  - 波特率= 9600波特
  - 字长= 9位
  - 一个停止位
  - 没有奇偶校验
  - 硬件流控制被禁用(RTS和CTS信号)
  - 启用接收和发送

2、硬件和软件环境

   - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   -LTM32F10X-EVAL 设置
    
    -  连接CN12和CN8之间的RS232 母电缆。
    - 使用键按钮连接到引脚PG.08 (EXTI Line8)
    - 使用唤醒按钮连接到引脚PA.00 (EXTI Line0)
    - 使用LED1和LED2分别连接到PF.06, PF0.7引脚

3.使用说明
