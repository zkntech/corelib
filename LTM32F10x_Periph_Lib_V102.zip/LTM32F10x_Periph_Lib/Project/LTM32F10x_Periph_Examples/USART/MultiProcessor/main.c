/**
  ******************************************************************************
  * @file    USART/MultiProcessor/main.c
  * @author  Embedded Application Team
  * @version V3.5.0
  * @date    08-April-2023
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, LETO TECHNOLOGY SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2023 Leto Technology</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "ltm32f10x.h"
#include "platform_config.h"
#include "ltm32_eval.h"

/** @addtogroup LTM32F10x_StdPeriph_Examples
  * @{
  */

/** @addtogroup USART_MultiProcessor
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
USART_InitTypeDef USART_InitStructure;

/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration( void );
void GPIO_Configuration( void );
void Delay( __IO uint32_t nCount );
__IO uint32_t TimingDelay = 0;

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  Main program
  * @param  None
  * @retval None
  */
int main( void )
{
	/*!< At this stage the microcontroller clock setting is already configured,
	     this is done through SystemInit() function which is called from startup
	     file (startup_ltm32f10x_xx.s) before to branch to application main.
	     To reconfigure the default setting of SystemInit() function, refer to
	     system_ltm32f10x.c file
	   */

	/* System Clocks Configuration */
	RCC_Configuration();

	/* Configure the GPIO ports */
	GPIO_Configuration();

	/* Initialize Leds, Wakeup and Key Buttons mounted on LTM3210X-EVAL board */
	LTM_EVAL_LEDInit( LED1 );
	LTM_EVAL_LEDInit( LED2 );
	LTM_EVAL_PBInit( BUTTON_WAKEUP, BUTTON_MODE_EXTI );
	LTM_EVAL_PBInit( BUTTON_KEY0, BUTTON_MODE_EXTI );

	/* Setup SysTick Timer for 1 msec interrupts  */
	if( SysTick_Config( SystemCoreClock / 1000 ) )
	{
		/* Capture error */
		while( 1 );
	}

	/* USARTy and USARTz configuration -------------------------------------------*/
	/* USARTy and USARTz configured as follow:
	      - BaudRate = 9600 baud
	      - Word Length = 9 Bits
	      - One Stop Bit
	      - No parity
	      - Hardware flow control disabled (RTS and CTS signals)
	      - Receive and transmit enabled
	*/
	USART_InitStructure.USART_BaudRate = 9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_9b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

	/* Configure USARTy */
	USART_Init( USARTy, &USART_InitStructure );
	/* Configure USARTz */
	USART_Init( USARTz, &USART_InitStructure );

	/* Enable the USARTy */
	USART_Cmd( USARTy, ENABLE );
	/* Enable the USARTz */
	USART_Cmd( USARTz, ENABLE );

	/* Set the USARTy Address */
	USART_SetAddress( USARTy, 0x1 );
	/* Set the USARTz Address */
	USART_SetAddress( USARTz, 0x2 );

	/* Select the USARTz WakeUp Method */
	USART_WakeUpConfig( USARTz, USART_WakeUp_AddressMark );

	while( 1 )
	{
		/* Send one byte from USARTy to USARTz */
		USART_SendData( USARTy, 0x33 );

		/* Wait while USART1 TXE = 0 */
		while( USART_GetFlagStatus( USARTz, USART_FLAG_TXE ) == RESET )
		{
		}

		if( USART_GetFlagStatus( USARTz, USART_FLAG_RXNE ) != RESET )
		{
			if( USART_ReceiveData( USARTz ) == 0x33 )
			{
				LTM_EVAL_LEDToggle( LED1 );
				Delay( 0x5FFFF );
				LTM_EVAL_LEDToggle( LED2 );
				Delay( 0x5FFFF );
			}
		}
	}
}

/**
  * @brief  Configures the different system clocks.
  * @param  None
  * @retval None
  */
void RCC_Configuration( void )
{
	/* Enable GPIO clock */
	RCC_APB2PeriphClockCmd( USARTy_GPIO_CLK | USARTz_GPIO_CLK | RCC_APB2Periph_AFIO, ENABLE );
	/* Enable USARTy Clock */
	RCC_APB2PeriphClockCmd( USARTy_CLK, ENABLE );
	/* Enable USARTz Clock */
	RCC_APB1PeriphClockCmd( USARTz_CLK, ENABLE );
}

/**
  * @brief  Configures the different GPIO ports.
  * @param  None
  * @retval None
  */
void GPIO_Configuration( void )
{
	GPIO_InitTypeDef GPIO_InitStructure;
	/* Configure USARTy Rx as input floating */
	GPIO_InitStructure.GPIO_Pin = USARTy_RxPin;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init( USARTy_GPIO, &GPIO_InitStructure );

	/* Configure USARTz Rx as input floating */
	GPIO_InitStructure.GPIO_Pin = USARTz_RxPin;
	GPIO_Init( USARTz_GPIO, &GPIO_InitStructure );

	/* Configure USARTy Tx as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = USARTy_TxPin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init( USARTy_GPIO, &GPIO_InitStructure );

	/* Configure USARTz Tx as alternate function push-pull */
	GPIO_InitStructure.GPIO_Pin = USARTz_TxPin;
	GPIO_Init( USARTz_GPIO, &GPIO_InitStructure );
}

/**
  * @brief  Inserts a delay time.
  * @param  nCount: specifies the delay time length.
  * @retval None
  */
void Delay( __IO uint32_t nCount )
{
	/* Decrement nCount value */
	for( ; nCount != 0; nCount-- );
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed( uint8_t *file, uint32_t line )
{
	/* User can add his own implementation to report the file name and line number,
	   ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	/* Infinite loop */
	while( 1 )
	{
	}
}

#endif

/**
  * @}
  */

/**
  * @}
  */

/******************* (C) COPYRIGHT 2023 Leto Technology *****END OF FILE****/
