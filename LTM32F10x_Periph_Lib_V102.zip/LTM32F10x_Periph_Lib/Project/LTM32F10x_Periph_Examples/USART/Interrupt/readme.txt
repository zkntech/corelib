1.例程描述

这个例子使用中断提供了USARTy和USARTz之间的基本通信。USARTy和USARTz可以是USART1和USART2或USART2和USART3，
具体取决于您使用的列拓科技核心板。

USARTz向USARTy发送TxBuffer2, USARTy向USARTz发送TxBuffer1。USARTy和USARTz接收到的数据分别存储在RxBuffer1和RxBuffer2中。
数据传输在ltm32f10x_it.c文件中的USARTy_IRQHandler和USARTz_IRQHandler中进行管理。

USARTy和USARTz配置如下:
  -波特率= 9600波特
  - 字长= 8位
  - 一个停止位
  -  No parity
  - 硬件流控制被禁用(RTS和CTS信号)
  - 启用接收和发送   

        


2、硬件和软件环境

  - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL设置 
    - 在CN12 (USART1)和CN8 (USART2)之间连接一根空调制解调器母/母RS232电缆。
    
  
3.使用说明
