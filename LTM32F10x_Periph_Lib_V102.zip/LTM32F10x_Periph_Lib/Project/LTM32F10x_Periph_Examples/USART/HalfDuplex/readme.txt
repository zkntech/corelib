1、例程描述 

这个例子提供了USARTy和USARTz在半双工模式下使用标志的基本通信。USARTy和USARTz可以是USART1和USART2或USART2和USART3，
具体取决于您使用的列拓科技核心板。

首先，USARTy使用TXE标志将数据从TxBuffer1缓冲区发送到USARTz。USARTz使用RXNE标志接收的数据存储在RxBuffer2中，然后与发送的数据进行比较，
比较的结果存储在“TransferStatus1”变量中。
 
然后，USARTz使用TXE标志将数据从TxBuffer2缓冲区发送到USARTy。USARTy使用RXNE标志接收到的数据存储在RxBuffer1中，然后与发送的数据进行比较，
比较的结果存储在“TransferStatus2”变量中。 


USARTy和USARTz配置如下:
 - 波特率= 230400波特
  - 字长= 8位
  - 一个停止位
  - 没有奇偶校验
  - 硬件流控制被禁用(RTS和CTS信号)
  - 启用接收和发送     

2、硬件和软件环境
            
 - 这个例子运行在LTM32F10x高密度设备。
  
   - 本例已通过LTM32F10X-EVAL(高密度)测试评估板并且可以很容易地定制任何其他支持的设备和开发板。

   - LTM32F10X-EVAL设置
    - 将USART1_Tx(PA.09)连接到USART2_Tx(PA.02)，并将一个上拉电阻连接到这条线。

3、使用说明